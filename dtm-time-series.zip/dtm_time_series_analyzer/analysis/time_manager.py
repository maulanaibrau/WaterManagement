from datetime import datetime
from typing import List

from qgis.core import QgsMapLayer, QgsDateTimeRange
from qgis.PyQt.QtCore import QDateTime


class TimeManager:
    """
    Assign temporal properties to raster layers so they can be visualized
    with QGIS' native temporal controller.
    """

    def assign_temporal_properties(self, layers: List[QgsMapLayer], dates: List[datetime]):
        if not layers or not dates or len(layers) != len(dates):
            return

        for layer, date in zip(layers, dates):
            # Use the temporal properties object provided by the layer
            props = layer.temporalProperties()
            start = QDateTime(date.year, date.month, date.day, 0, 0)
            end = QDateTime(date.year, date.month, date.day, 23, 59)
            props.setIsActive(True)
            props.setTemporalRange(QgsDateTimeRange(start, end))
            layer.triggerRepaint()

