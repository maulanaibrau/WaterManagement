import os

from qgis.PyQt import uic
from qgis.PyQt.QtWidgets import QDialog


FORM_CLASS, _ = uic.loadUiType(
    os.path.join(os.path.dirname(__file__), "dtm_time_series_analyzer_dialog_base.ui")
)


class DtmTimeSeriesAnalyzerDialog(QDialog, FORM_CLASS):
    """Main dialog for the DTM Time Series Analyzer plugin."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)

