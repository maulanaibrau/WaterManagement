from typing import Dict, Any

import numpy as np


class VolumeCalculator:
    """Compute cut, fill, and net volume from a DEM of Difference raster."""

    def compute_volume(self, diff_array, geotransform) -> Dict[str, Any]:
        """
        Volume = sum( elevation_change × pixel_area )

        Returns a dict with cut_volume (negative), fill_volume (positive), and net_volume.
        """
        diff = np.array(diff_array, dtype=float)
        mask = ~np.isnan(diff)
        diff_valid = diff[mask]

        # Pixel area from geotransform (assumes north-up)
        pixel_width = geotransform[1]
        pixel_height = geotransform[5]
        pixel_area = abs(pixel_width * pixel_height)

        cut = diff_valid[diff_valid < 0].sum() * pixel_area
        fill = diff_valid[diff_valid > 0].sum() * pixel_area
        net = diff_valid.sum() * pixel_area

        return {
            "cut_volume": float(cut),
            "fill_volume": float(fill),
            "net_volume": float(net),
        }

