from typing import List, Dict, Any

from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure


class VolumeChartDialog(QDialog):
    """Dialog embedding a matplotlib chart of cumulative volume change over time."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Cumulative Volume Change Over Time")
        self.figure = Figure(figsize=(6, 4))
        self.canvas = FigureCanvas(self.figure)

        layout = QVBoxLayout()
        layout.addWidget(self.canvas)
        self.setLayout(layout)

    def update_chart(self, pair_stats: List[Dict[str, Any]]):
        """
        Plot cumulative net volume change over time.

        X-axis: time (Date2 of each pair)
        Y-axis: cumulative net volume.
        """
        self.figure.clear()
        ax = self.figure.add_subplot(111)

        if not pair_stats:
            self.canvas.draw()
            return

        dates = [s["date2"] for s in pair_stats]
        net_volumes = [s["net_volume"] for s in pair_stats]

        cumulative = []
        acc = 0.0
        for v in net_volumes:
            acc += v
            cumulative.append(acc)

        ax.plot(dates, cumulative, marker="o")
        ax.set_xlabel("Time")
        ax.set_ylabel("Cumulative Volume Change")
        ax.set_title("Cumulative Volume Change Over Time")
        ax.grid(True)
        self.figure.autofmt_xdate()
        self.canvas.draw()

