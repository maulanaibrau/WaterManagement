from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Dict, Any

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QPushButton,
    QListWidget,
    QListWidgetItem,
    QFileDialog,
    QMessageBox,
)
from qgis.PyQt.QtGui import QColor

from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure

from qgis.core import (
    QgsVectorLayer,
    QgsFeature,
    QgsGeometry,
    QgsPoint,
    QgsFields,
    QgsField,
    QgsWkbTypes,
    QgsProject,
    QgsVectorFileWriter,
    QgsCoordinateReferenceSystem,
)
from qgis.PyQt.QtCore import QVariant

from ..analysis.profile_sampler import SampledProfile


@dataclass
class _ProfileLine:
    profile: SampledProfile
    mpl_line: Any


class CrossSectionDialog(QDialog):
    """Interactive cross-section plot dialog with per-profile visibility toggles and exports."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("DTM Cross Section")

        self.figure = Figure(figsize=(8, 5))
        self.canvas = FigureCanvas(self.figure)
        self.toolbar = NavigationToolbar(self.canvas, self)

        self.ax = self.figure.add_subplot(111)

        self.listWidget = QListWidget()
        self.listWidget.itemChanged.connect(self._on_item_changed)

        self.exportPngButton = QPushButton("Export PNG/JPEG")
        self.exportPngButton.clicked.connect(self.export_png_jpeg)

        self.exportVectorButton = QPushButton("Export DXF/Shapefile")
        self.exportVectorButton.clicked.connect(self.export_vector)

        left = QVBoxLayout()
        left.addWidget(self.listWidget)
        left.addWidget(self.exportPngButton)
        left.addWidget(self.exportVectorButton)
        left.addStretch(1)

        right = QVBoxLayout()
        right.addWidget(self.toolbar)
        right.addWidget(self.canvas)

        main = QHBoxLayout()
        main.addLayout(left, 0)
        main.addLayout(right, 1)
        self.setLayout(main)

        self._lines: List[_ProfileLine] = []
        self._last_line_geom: Optional[QgsGeometry] = None
        self._last_crs: Optional[QgsCoordinateReferenceSystem] = None

    def set_profiles(self, profiles: List[SampledProfile], line_geom: QgsGeometry, crs: QgsCoordinateReferenceSystem):
        self._last_line_geom = line_geom
        self._last_crs = crs

        self.ax.clear()
        self._lines = []
        self.listWidget.blockSignals(True)
        self.listWidget.clear()

        # Use Matplotlib default cycle but ensure distinct colors
        for idx, prof in enumerate(profiles):
            (mpl_line,) = self.ax.plot(prof.distances, prof.elevations, label=prof.name, linewidth=1.5)
            self._lines.append(_ProfileLine(profile=prof, mpl_line=mpl_line))

            item = QListWidgetItem(prof.name)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked)
            # show a hint color
            c = mpl_line.get_color()
            item.setForeground(QColor(c))
            self.listWidget.addItem(item)

        self.listWidget.blockSignals(False)

        self.ax.set_xlabel("Distance along line")
        self.ax.set_ylabel("Elevation")
        self.ax.set_title("Cross Section (all DTMs)")
        self.ax.grid(True)
        self.ax.legend(loc="best")
        self.canvas.draw()

    def _on_item_changed(self, item: QListWidgetItem):
        idx = self.listWidget.row(item)
        if idx < 0 or idx >= len(self._lines):
            return
        visible = item.checkState() == Qt.Checked
        self._lines[idx].mpl_line.set_visible(visible)
        # Update legend based on visible lines
        self.ax.legend(loc="best")
        self.canvas.draw_idle()

    def export_png_jpeg(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Cross Section", "", "PNG (*.png);;JPEG (*.jpg *.jpeg)"
        )
        if not path:
            return
        self.figure.savefig(path, dpi=200, bbox_inches="tight")

    def _profiles_to_vector_layer(self) -> Optional[QgsVectorLayer]:
        if not self._lines or self._last_line_geom is None or self._last_crs is None:
            return None

        # Build a LineStringZ for each profile where Z is sampled elevation.
        vl = QgsVectorLayer(f"LineStringZ?crs={self._last_crs.authid()}", "cross_section_profiles", "memory")
        pr = vl.dataProvider()

        fields = QgsFields()
        fields.append(QgsField("name", QVariant.String))
        pr.addAttributes(fields)
        vl.updateFields()

        feats: List[QgsFeature] = []
        for pl in self._lines:
            prof = pl.profile
            if not prof.distances or not prof.elevations or len(prof.distances) != len(prof.elevations):
                continue

            # Reconstruct XY positions along the drawn line, set Z from elevation.
            pts: List[QgsPoint] = []
            for d, z in zip(prof.distances, prof.elevations):
                g = self._last_line_geom.interpolate(d)
                if g.isEmpty():
                    continue
                p = g.asPoint()
                pts.append(QgsPoint(p.x(), p.y(), float(z)))

            if len(pts) < 2:
                continue

            f = QgsFeature(vl.fields())
            f.setAttribute("name", prof.name)
            f.setGeometry(QgsGeometry.fromPolyline(pts))
            feats.append(f)

        pr.addFeatures(feats)
        vl.updateExtents()
        return vl

    def export_vector(self):
        vl = self._profiles_to_vector_layer()
        if vl is None:
            QMessageBox.warning(self, "Export", "No cross-section profiles available to export.")
            return

        path, _ = QFileDialog.getSaveFileName(
            self,
            "Export Cross Section Geometry",
            "",
            "Shapefile (*.shp);;DXF (*.dxf)",
        )
        if not path:
            return

        if path.lower().endswith(".dxf"):
            driver = "DXF"
        else:
            driver = "ESRI Shapefile"
            if not path.lower().endswith(".shp"):
                path += ".shp"

        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = driver
        options.fileEncoding = "UTF-8"

        res, err = QgsVectorFileWriter.writeAsVectorFormatV2(
            vl,
            path,
            QgsProject.instance().transformContext(),
            options,
        )
        if res != QgsVectorFileWriter.NoError:
            QMessageBox.warning(self, "Export", f"Export failed: {err}")
        else:
            QMessageBox.information(self, "Export", "Export completed successfully.")

