# This file is normally generated from resources.qrc using pyrcc5.
# It is intentionally left minimal so that the plugin does not fail
# if the compiled resources are missing. Icons are optional for this plugin.

