from .dtm_time_series_analyzer import DtmTimeSeriesAnalyzerPlugin


def classFactory(iface):  # QGIS calls this to instantiate the plugin
    return DtmTimeSeriesAnalyzerPlugin(iface)

