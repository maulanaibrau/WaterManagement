import os
import math
from typing import List, Dict, Any

from qgis.PyQt.QtCore import QCoreApplication, QSettings, QTranslator, qVersion, QLocale, Qt
from qgis.PyQt.QtWidgets import QAction, QFileDialog, QMessageBox
from qgis.core import QgsProject

from .dtm_time_series_analyzer_dialog import DtmTimeSeriesAnalyzerDialog
from .analysis.raster_loader import RasterLoader
from .analysis.dem_difference import DemDifferenceCalculator
from .analysis.volume_calculator import VolumeCalculator
from .analysis.statistics import StatisticsCalculator
from .analysis.time_manager import TimeManager
from .analysis.profile_sampler import ProfileSampler
from .visualization.charts import VolumeChartDialog
from .visualization.cross_section import CrossSectionDialog
from .visualization.cross_section_tool import CrossSectionLineTool


class DtmTimeSeriesAnalyzerPlugin:
    """Main QGIS plugin class."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions: List[QAction] = []
        self.menu = self.tr("DTM Time Series Analyzer")
        self.toolbar = self.iface.addToolBar("DTM Time Series Analyzer")
        self.toolbar.setObjectName("DTMTimeSeriesAnalyzerToolbar")

        self.dlg: DtmTimeSeriesAnalyzerDialog | None = None
        self.volume_chart_dlg: VolumeChartDialog | None = None
        self.cross_section_dlg: CrossSectionDialog | None = None
        self._cross_section_tool: CrossSectionLineTool | None = None
        self._previous_map_tool = None

        self.translator = None
        self._init_locale()

        self.raster_loader = RasterLoader()
        self.dem_diff_calc = DemDifferenceCalculator()
        self.volume_calc = VolumeCalculator()
        self.stats_calc = StatisticsCalculator()
        self.time_manager = TimeManager()
        self.profile_sampler = ProfileSampler()

        self.dataset_info: List[Dict[str, Any]] = []
        self.pair_stats: List[Dict[str, Any]] = []

    def tr(self, message):
        return QCoreApplication.translate("DtmTimeSeriesAnalyzer", message)

    def _init_locale(self):
        locale = QSettings().value("locale/userLocale", QLocale().name())
        if locale:
            locale_path = os.path.join(self.plugin_dir, "i18n", f"dtm_time_series_analyzer_{locale}.qm")
            if os.path.exists(locale_path):
                self.translator = QTranslator()
                self.translator.load(locale_path)
                if qVersion() > "4.3.3":
                    QCoreApplication.installTranslator(self.translator)

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        self.add_action(
            icon_path,
            text=self.tr("DTM Time Series Analyzer"),
            callback=self.run,
            parent=self.iface.mainWindow(),
        )

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None,
    ):
        action = QAction(text, parent)
        if os.path.exists(icon_path):
            action.setIcon(self.iface.mainWindow().style().standardIcon(QAction.StandardKey.NoStandardKey))
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if add_to_toolbar:
            self.toolbar.addAction(action)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)
        return action

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(self.menu, action)
            self.iface.removeToolBarIcon(action)
        if self.toolbar:
            del self.toolbar

    def _ensure_dialog(self):
        if self.dlg is None:
            self.dlg = DtmTimeSeriesAnalyzerDialog()
            self.dlg.selectFolderButton.clicked.connect(self.select_folder)
            self.dlg.runAnalysisButton.clicked.connect(self.run_analysis)
            self.dlg.drawCrossSectionButton.clicked.connect(self.draw_cross_section)
            self.dlg.exportStatsButton.clicked.connect(self.export_statistics)
            self.dlg.generateChartButton.clicked.connect(self.show_chart)
            # Make it obvious analysis is required for stats/chart/export
            self.dlg.exportStatsButton.setEnabled(False)
            self.dlg.generateChartButton.setEnabled(False)

    def run(self):
        self._ensure_dialog()
        self.dlg.show()
        self.dlg.raise_()
        self.dlg.activateWindow()

    def select_folder(self):
        folder = QFileDialog.getExistingDirectory(
            self.iface.mainWindow(),
            self.tr("Select DTM Folder"),
            "",
        )
        if folder:
            self.dlg.folderLineEdit.setText(folder)
            self.load_rasters(folder)

    def load_rasters(self, folder: str):
        self.dataset_info = self.raster_loader.load_rasters_from_folder(folder, self.iface)
        self._populate_dataset_table()
        # New data invalidates previous analysis outputs
        self.pair_stats = []
        self._populate_stats_table()
        self.dlg.exportStatsButton.setEnabled(False)
        self.dlg.generateChartButton.setEnabled(False)

    def _populate_dataset_table(self):
        table = self.dlg.datasetsTable
        table.clear()
        table.setColumnCount(3)
        table.setHorizontalHeaderLabels(["Date", "File Name", "Label"])
        table.setRowCount(len(self.dataset_info))

        from qgis.PyQt.QtWidgets import QTableWidgetItem

        for row, info in enumerate(self.dataset_info):
            # Month as name (e.g., 2026-Mar-16)
            date_str = info["date"].strftime("%Y-%b-%d")
            table.setItem(row, 0, QTableWidgetItem(date_str))
            table.setItem(row, 1, QTableWidgetItem(os.path.basename(info["path"])))
            table.setItem(row, 2, QTableWidgetItem(info["label"]))

        table.resizeColumnsToContents()

    def run_analysis(self):
        if len(self.dataset_info) < 2:
            QMessageBox.warning(
                self.iface.mainWindow(),
                self.tr("DTM Time Series Analyzer"),
                self.tr("At least two valid DTM rasters are required for analysis."),
            )
            return

        self.pair_stats = []
        # Always create consecutive intervals aligned with dataset order:
        # (1-2), (2-3), ..., (n-1 - n)
        for i in range(len(self.dataset_info) - 1):
            d1 = self.dataset_info[i]
            d2 = self.dataset_info[i + 1]

            diff_result = self.dem_diff_calc.compute_difference(
                d1["path"], d2["path"], output_suffix=f"_DoD_{i+1}", add_to_canvas=True, iface=self.iface
            )

            if diff_result is None:
                # Keep row alignment even if this pair fails (e.g., different grids)
                pair_stat = {
                    "date1": d1["date"],
                    "date2": d2["date"],
                    "mean_change": float("nan"),
                    "rmse": float("nan"),
                    "cut_volume": float("nan"),
                    "fill_volume": float("nan"),
                    "net_volume": float("nan"),
                }
                self.pair_stats.append(pair_stat)
                continue

            diff_array = diff_result["diff_array"]
            geotransform = diff_result["geotransform"]

            volume = self.volume_calc.compute_volume(diff_array, geotransform)
            stats = self.stats_calc.compute_statistics_from_arrays(diff_array)

            pair_stat = {
                "date1": d1["date"],
                "date2": d2["date"],
                "mean_change": stats["mean_change"],
                "rmse": stats["rmse"],
                "cut_volume": volume["cut_volume"],
                "fill_volume": volume["fill_volume"],
                "net_volume": volume["net_volume"],
            }
            self.pair_stats.append(pair_stat)

        self._populate_stats_table()
        self.dlg.exportStatsButton.setEnabled(True)
        self.dlg.generateChartButton.setEnabled(True)

        # Assign temporal properties to original rasters
        layers = [info["layer"] for info in self.dataset_info if info.get("layer")]
        self.time_manager.assign_temporal_properties(layers, [info["date"] for info in self.dataset_info])

    def _populate_stats_table(self):
        table = self.dlg.statsTable
        table.clear()
        table.setColumnCount(7)
        table.setHorizontalHeaderLabels(
            [
                "Date1",
                "Date2",
                "Mean Change (m)",
                "RMSE (m)",
                "Cut Volume (m³)",
                "Fill Volume (m³)",
                "Net Volume (m³)",
            ]
        )
        # Keep table aligned with dataset intervals even if analysis failed for some pairs
        table.setRowCount(max(0, len(self.dataset_info) - 1))

        from qgis.PyQt.QtWidgets import QTableWidgetItem

        def fmt3(v: float) -> str:
            if v is None:
                return "N/A"
            try:
                if isinstance(v, float) and math.isnan(v):
                    return "N/A"
            except Exception:
                pass
            try:
                return f"{float(v):,.3f}"
            except Exception:
                return "N/A"

        for row in range(max(0, len(self.dataset_info) - 1)):
            d1 = self.dataset_info[row]["date"]
            d2 = self.dataset_info[row + 1]["date"]
            table.setItem(row, 0, QTableWidgetItem(d1.strftime("%Y-%m-%d")))
            table.setItem(row, 1, QTableWidgetItem(d2.strftime("%Y-%m-%d")))

            s = self.pair_stats[row] if row < len(self.pair_stats) else None
            if s is None:
                table.setItem(row, 2, QTableWidgetItem("N/A"))
                table.setItem(row, 3, QTableWidgetItem("N/A"))
                table.setItem(row, 4, QTableWidgetItem("N/A"))
                table.setItem(row, 5, QTableWidgetItem("N/A"))
                table.setItem(row, 6, QTableWidgetItem("N/A"))
            else:
                table.setItem(row, 2, QTableWidgetItem(fmt3(s.get("mean_change"))))
                table.setItem(row, 3, QTableWidgetItem(fmt3(s.get("rmse"))))
                table.setItem(row, 4, QTableWidgetItem(fmt3(s.get("cut_volume"))))
                table.setItem(row, 5, QTableWidgetItem(fmt3(s.get("fill_volume"))))
                table.setItem(row, 6, QTableWidgetItem(fmt3(s.get("net_volume"))))

        table.resizeColumnsToContents()

    def export_statistics(self):
        if not self.pair_stats:
            QMessageBox.warning(
                self.iface.mainWindow(),
                self.tr("DTM Time Series Analyzer"),
                self.tr("No statistics available. Please run the analysis first."),
            )
            return

        path, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(),
            self.tr("Export Statistics to CSV"),
            "",
            "CSV Files (*.csv)",
        )
        if not path:
            return

        import csv

        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["Date1", "Date2", "Mean Change", "RMSE", "Cut Volume", "Fill Volume", "Net Volume"])
            for s in self.pair_stats:
                writer.writerow(
                    [
                        s["date1"].strftime("%Y-%m-%d"),
                        s["date2"].strftime("%Y-%m-%d"),
                        f"{s['mean_change']:.6f}",
                        f"{s['rmse']:.6f}",
                        f"{s['cut_volume']:.6f}",
                        f"{s['fill_volume']:.6f}",
                        f"{s['net_volume']:.6f}",
                    ]
                )

        QMessageBox.information(
            self.iface.mainWindow(),
            self.tr("DTM Time Series Analyzer"),
            self.tr("Statistics exported successfully."),
        )

    def show_chart(self):
        if not self.pair_stats:
            QMessageBox.warning(
                self.iface.mainWindow(),
                self.tr("DTM Time Series Analyzer"),
                self.tr("No statistics available. Please run the analysis first."),
            )
            return

        if self.volume_chart_dlg is None:
            self.volume_chart_dlg = VolumeChartDialog(self.iface.mainWindow())

        self.volume_chart_dlg.update_chart(self.dataset_info, self.pair_stats)
        self.volume_chart_dlg.show()
        self.volume_chart_dlg.raise_()
        self.volume_chart_dlg.activateWindow()

    def draw_cross_section(self):
        if not self.dataset_info:
            QMessageBox.warning(
                self.iface.mainWindow(),
                self.tr("DTM Time Series Analyzer"),
                self.tr("Please load DTM rasters first (Select DTM Folder)."),
            )
            return

        canvas = self.iface.mapCanvas()
        self._previous_map_tool = canvas.mapTool()

        def _finished(geom):
            try:
                profiles = self.profile_sampler.sample_profiles(
                    geom,
                    canvas.mapSettings().destinationCrs(),
                    self.dataset_info,
                    step=None,
                )
                if not profiles:
                    QMessageBox.warning(
                        self.iface.mainWindow(),
                        self.tr("DTM Time Series Analyzer"),
                        self.tr("No profile samples could be generated (check raster coverage / CRS)."),
                    )
                    return

                if self.cross_section_dlg is None:
                    self.cross_section_dlg = CrossSectionDialog(self.iface.mainWindow())

                self.cross_section_dlg.set_profiles(
                    profiles,
                    geom,
                    canvas.mapSettings().destinationCrs(),
                )
                self.cross_section_dlg.show()
                self.cross_section_dlg.raise_()
                self.cross_section_dlg.activateWindow()
            finally:
                if self._previous_map_tool is not None:
                    canvas.setMapTool(self._previous_map_tool)

        def _cancelled():
            if self._previous_map_tool is not None:
                canvas.setMapTool(self._previous_map_tool)

        self._cross_section_tool = CrossSectionLineTool(canvas, on_finished=_finished, on_cancelled=_cancelled)
        canvas.setMapTool(self._cross_section_tool)

