import os
from typing import Optional, Dict, Any

import numpy as np
from osgeo import gdal
from qgis.core import (
    QgsRasterLayer,
    QgsColorRampShader,
    QgsRasterShader,
    QgsSingleBandPseudoColorRenderer,
)
from qgis.PyQt.QtGui import QColor


class DemDifferenceCalculator:
    """
    Compute DEM of Difference (DoD) rasters between consecutive DTM rasters.

    Assumes rasters share the same projection, resolution, and extent.
    """

    def compute_difference(
        self,
        path1: str,
        path2: str,
        output_suffix: str = "_DoD",
        add_to_canvas: bool = True,
        iface=None,
    ) -> Optional[Dict[str, Any]]:
        """
        Compute DEM2 - DEM1 and write result to GeoTIFF.

        Returns a dict containing:
            - diff_path: path to output GeoTIFF
            - diff_array: numpy array of differences
            - geotransform: GDAL geotransform tuple
        or None if computation fails.
        """
        # Avoid GDAL FutureWarning and make behavior explicit
        try:
            gdal.UseExceptions()
        except Exception:
            pass

        ds1 = gdal.Open(path1)
        ds2 = gdal.Open(path2)
        if ds1 is None or ds2 is None:
            return None

        band1 = ds1.GetRasterBand(1)
        band2 = ds2.GetRasterBand(1)

        # Read arrays; if grids differ, warp ds2 onto ds1 grid in-memory
        arr1 = band1.ReadAsArray().astype(float)

        if ds1.RasterXSize != ds2.RasterXSize or ds1.RasterYSize != ds2.RasterYSize or ds1.GetGeoTransform() != ds2.GetGeoTransform() or ds1.GetProjection() != ds2.GetProjection():
            try:
                gt = ds1.GetGeoTransform()
                xmin = gt[0]
                ymax = gt[3]
                xmax = xmin + gt[1] * ds1.RasterXSize
                ymin = ymax + gt[5] * ds1.RasterYSize
                warp_opts = gdal.WarpOptions(
                    format="MEM",
                    outputBounds=(xmin, ymin, xmax, ymax),
                    width=ds1.RasterXSize,
                    height=ds1.RasterYSize,
                    dstSRS=ds1.GetProjection(),
                    resampleAlg="bilinear",
                )
                ds2w = gdal.Warp("", ds2, options=warp_opts)
                if ds2w is None:
                    return None
                ds2 = ds2w
                band2 = ds2.GetRasterBand(1)
            except Exception:
                return None

        arr2 = band2.ReadAsArray().astype(float)

        if arr1.shape != arr2.shape:
            return None

        nodata1 = band1.GetNoDataValue()
        nodata2 = band2.GetNoDataValue()

        mask = np.ones_like(arr1, dtype=bool)
        if nodata1 is not None:
            mask &= arr1 != nodata1
        if nodata2 is not None:
            mask &= arr2 != nodata2

        diff = np.zeros_like(arr1, dtype=float)
        diff[mask] = arr2[mask] - arr1[mask]
        diff[~mask] = np.nan

        driver = gdal.GetDriverByName("GTiff")
        base2 = os.path.splitext(os.path.basename(path2))[0]
        out_name = f"{base2}{output_suffix}.tif"
        out_path = os.path.join(os.path.dirname(path2), out_name)

        out_ds = driver.Create(out_path, ds1.RasterXSize, ds1.RasterYSize, 1, gdal.GDT_Float32)
        out_ds.SetGeoTransform(ds1.GetGeoTransform())
        out_ds.SetProjection(ds1.GetProjection())
        out_band = out_ds.GetRasterBand(1)
        out_band.WriteArray(diff)
        out_band.SetNoDataValue(np.nan)
        out_band.FlushCache()
        out_ds.FlushCache()

        if add_to_canvas and iface is not None:
            layer_name = os.path.basename(out_path)
            layer = QgsRasterLayer(out_path, layer_name)
            if layer.isValid():
                iface.addRasterLayer(out_path, layer_name)
                # Apply a red-only singleband pseudocolor ramp (white -> dark red)
                try:
                    finite = diff[np.isfinite(diff)]
                    if finite.size > 0:
                        vmin = float(np.nanmin(finite))
                        vmax = float(np.nanmax(finite))
                        if vmin == vmax:
                            vmax = vmin + 1e-6

                        shader = QgsRasterShader()
                        ramp = QgsColorRampShader()
                        ramp.setColorRampType(QgsColorRampShader.Interpolated)

                        # 5 stops: white -> cream -> orange -> red -> dark red
                        items = [
                            QgsColorRampShader.ColorRampItem(vmin, QColor("#ffffff"), "min"),
                            QgsColorRampShader.ColorRampItem(vmin + 0.25 * (vmax - vmin), QColor("#fff2cc"), ""),
                            QgsColorRampShader.ColorRampItem(vmin + 0.50 * (vmax - vmin), QColor("#f6b26b"), ""),
                            QgsColorRampShader.ColorRampItem(vmin + 0.75 * (vmax - vmin), QColor("#e06666"), ""),
                            QgsColorRampShader.ColorRampItem(vmax, QColor("#990000"), "max"),
                        ]
                        ramp.setColorRampItemList(items)
                        shader.setRasterShaderFunction(ramp)

                        renderer = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, shader)
                        layer.setRenderer(renderer)
                        layer.triggerRepaint()
                except Exception:
                    pass

        return {
            "diff_path": out_path,
            "diff_array": diff,
            "geotransform": ds1.GetGeoTransform(),
        }

