import os
from datetime import datetime
from typing import List, Dict, Any

from qgis.core import QgsRasterLayer
from qgis.PyQt.QtWidgets import QMessageBox


class RasterLoader:
    """Load GeoTIFF rasters from a folder, parse dates from filenames, and sort chronologically."""

    def _parse_date_from_filename(self, filename: str):
        """
        Parse date from filename using rule:

        date_part = filename.split("_")[0]
        date = datetime.strptime(date_part, "%Y%m%d")

        Returns datetime or raises ValueError.
        """
        name_no_ext = os.path.splitext(os.path.basename(filename))[0]
        parts = name_no_ext.split("_")
        if not parts:
            raise ValueError("No date part found in filename.")
        date_part = parts[0]
        if len(date_part) != 8:
            raise ValueError("Date part must have 8 digits (YYYYMMDD).")
        return datetime.strptime(date_part, "%Y%m%d")

    def load_rasters_from_folder(self, folder: str, iface) -> List[Dict[str, Any]]:
        """
        Load all .tif rasters in folder, parse dates, sort by date.
        Invalid filenames are skipped with a warning.
        """
        raster_infos: List[Dict[str, Any]] = []
        invalid_files: List[str] = []

        for fname in os.listdir(folder):
            if not fname.lower().endswith(".tif") and not fname.lower().endswith(".tiff"):
                continue
            path = os.path.join(folder, fname)
            try:
                date = self._parse_date_from_filename(fname)
            except Exception:
                invalid_files.append(fname)
                continue

            # Label is the part after the underscore, if present
            name_no_ext = os.path.splitext(fname)[0]
            parts = name_no_ext.split("_", 1)
            label = parts[1] if len(parts) > 1 else ""

            layer = QgsRasterLayer(path, fname)
            if not layer.isValid():
                invalid_files.append(fname)
                continue

            raster_infos.append(
                {
                    "path": path,
                    "date": date,
                    "label": label,
                    "layer": layer,
                }
            )

        # Sort chronologically by date
        raster_infos.sort(key=lambda x: x["date"])

        # Add layers to QGIS map
        for info in raster_infos:
            iface.addRasterLayer(info["path"], os.path.basename(info["path"]))

        if invalid_files:
            msg = (
                "The following files were skipped because they do not follow the required naming convention "
                "YYYYMMDD_XXXXX.tif or could not be loaded:\n\n"
            )
            msg += "\n".join(invalid_files)
            QMessageBox.warning(iface.mainWindow(), "DTM Time Series Analyzer", msg)

        return raster_infos

