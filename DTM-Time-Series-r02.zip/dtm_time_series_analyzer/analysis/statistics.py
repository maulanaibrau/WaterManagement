from typing import Dict, Any

import numpy as np


class StatisticsCalculator:
    """Compute mean elevation change and RMSE for DEM of Difference arrays."""

    def compute_statistics_from_arrays(self, diff_array) -> Dict[str, Any]:
        """
        RMSE = sqrt(mean((DEM2 - DEM1)^2))
        Here diff_array = DEM2 - DEM1.
        """
        diff = np.array(diff_array, dtype=float)
        mask = ~np.isnan(diff)
        if not mask.any():
            return {"mean_change": 0.0, "rmse": 0.0}

        diff_valid = diff[mask]
        mean_change = float(diff_valid.mean())
        rmse = float(np.sqrt((diff_valid ** 2).mean()))
        return {"mean_change": mean_change, "rmse": rmse}

