from __future__ import annotations

from dataclasses import dataclass
from typing import List, Dict, Any, Optional

import math

from qgis.core import (
    QgsRasterLayer,
    QgsPointXY,
    QgsGeometry,
    QgsCoordinateTransform,
    QgsProject,
    QgsDistanceArea,
    QgsWkbTypes,
)


@dataclass(frozen=True)
class SampledProfile:
    name: str
    distances: List[float]
    elevations: List[float]
    crs_authid: str


class ProfileSampler:
    """Sample elevation profiles from rasters along a line drawn on the map canvas."""

    def _default_step(self, raster: QgsRasterLayer) -> float:
        # Prefer raster pixel size as sampling step
        try:
            sx = float(raster.rasterUnitsPerPixelX())
            sy = float(raster.rasterUnitsPerPixelY())
            step = max(1e-9, (abs(sx) + abs(sy)) / 2.0)
            return step
        except Exception:
            return 1.0

    def sample_profiles(
        self,
        line_map_crs: QgsGeometry,
        map_crs,
        rasters: List[Dict[str, Any]],
        step: Optional[float] = None,
    ) -> List[SampledProfile]:
        """
        rasters: list of dicts containing at least:
          - layer: QgsRasterLayer
          - label: str
          - date: datetime
        """
        if line_map_crs is None or line_map_crs.isEmpty():
            return []

        # QgsGeometry.LineGeometry is not available in some QGIS builds;
        # QgsWkbTypes.LineGeometry is the stable enum for geometry type.
        if line_map_crs.type() != QgsWkbTypes.LineGeometry:
            return []

        # Distance calculator in map CRS units (best effort)
        da = QgsDistanceArea()
        da.setSourceCrs(map_crs, QgsProject.instance().transformContext())

        total_len = da.measureLength(line_map_crs)
        if total_len <= 0:
            return []

        profiles: List[SampledProfile] = []

        for info in rasters:
            layer: QgsRasterLayer = info.get("layer")
            if layer is None or not layer.isValid():
                continue

            this_step = step if step and step > 0 else self._default_step(layer)
            # Guard against absurd steps in degrees etc.
            this_step = max(this_step, total_len / 2000.0)  # cap at ~2000 samples

            transform = QgsCoordinateTransform(map_crs, layer.crs(), QgsProject.instance())
            provider = layer.dataProvider()

            distances: List[float] = []
            elevations: List[float] = []

            n = int(math.floor(total_len / this_step)) + 1
            for i in range(n + 1):
                d = min(i * this_step, total_len)
                pt_map = line_map_crs.interpolate(d)
                if pt_map.isEmpty():
                    continue
                p = pt_map.asPoint()
                try:
                    p_layer = transform.transform(QgsPointXY(p))
                except Exception:
                    continue

                val, ok = provider.sample(p_layer, 1)
                if not ok:
                    continue

                # provider.sample may return None/nan for nodata; keep gaps as nan for plotting
                try:
                    z = float(val)
                except Exception:
                    continue

                distances.append(float(d))
                elevations.append(z)

            name = info.get("label") or layer.name()
            # Prefer displaying the parsed date in the legend when available
            if info.get("date"):
                name = f"{info['date'].strftime('%Y-%m-%d')} | {name}".rstrip(" |")

            profiles.append(
                SampledProfile(
                    name=name,
                    distances=distances,
                    elevations=elevations,
                    crs_authid=layer.crs().authid(),
                )
            )

        return profiles

