from __future__ import annotations

from typing import Callable, Optional

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor
from qgis.gui import QgsMapTool, QgsRubberBand
from qgis.core import QgsWkbTypes, QgsPointXY, QgsGeometry


class CrossSectionLineTool(QgsMapTool):
    """
    Simple interactive line drawing tool:
    - Left click: add vertex
    - Right click: finish line
    - Esc: cancel
    """

    def __init__(self, canvas, on_finished: Callable[[QgsGeometry], None], on_cancelled: Optional[Callable[[], None]] = None):
        super().__init__(canvas)
        self.canvas = canvas
        self.on_finished = on_finished
        self.on_cancelled = on_cancelled

        self._rubber = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self._rubber.setColor(QColor(255, 0, 0, 200))
        self._rubber.setWidth(2)
        self._points: list[QgsPointXY] = []

    def deactivate(self):
        super().deactivate()
        self._clear()

    def _clear(self):
        self._points = []
        if self._rubber:
            self._rubber.reset(QgsWkbTypes.LineGeometry)

    def canvasPressEvent(self, e):
        if e.button() == Qt.RightButton:
            if len(self._points) >= 2:
                geom = QgsGeometry.fromPolylineXY(self._points)
                self.on_finished(geom)
            else:
                if self.on_cancelled:
                    self.on_cancelled()
            self._clear()
            return

        if e.button() == Qt.LeftButton:
            p = self.toMapCoordinates(e.pos())
            pt = QgsPointXY(p)
            self._points.append(pt)
            self._rubber.addPoint(pt, True)

    def canvasMoveEvent(self, e):
        if not self._points:
            return
        p = self.toMapCoordinates(e.pos())
        self._rubber.movePoint(QgsPointXY(p))

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self._clear()
            if self.on_cancelled:
                self.on_cancelled()

