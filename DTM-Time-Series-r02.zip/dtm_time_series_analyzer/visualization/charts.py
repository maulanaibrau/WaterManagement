from typing import List, Dict, Any

import math

from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure


class VolumeChartDialog(QDialog):
    """Dialog embedding a matplotlib chart of cumulative volume change over time."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Cumulative Volume Change Over Time")
        self.figure = Figure(figsize=(6, 4))
        self.canvas = FigureCanvas(self.figure)

        layout = QVBoxLayout()
        layout.addWidget(self.canvas)
        self.setLayout(layout)

    def update_chart(self, dataset_info: List[Dict[str, Any]], pair_stats: List[Dict[str, Any]]):
        """
        Plot cumulative net volume change over time.

        X-axis: dataset dates (including first date)
        Y-axis: cumulative net volume (starts at 0 on first date).
        """
        self.figure.clear()
        ax = self.figure.add_subplot(111)

        if not dataset_info or len(dataset_info) < 2:
            self.canvas.draw()
            return

        dates = [d["date"] for d in dataset_info]

        # Align net volumes with dataset intervals; start cumulative at 0 for first date
        cumulative = [0.0]
        acc = 0.0
        for i in range(len(dates) - 1):
            v = float("nan")
            if i < len(pair_stats):
                v = pair_stats[i].get("net_volume", float("nan"))
            try:
                v = float(v)
                if math.isnan(v):
                    # if a pair failed, treat as 0 for cumulative curve (still keeps time alignment)
                    v = 0.0
            except Exception:
                v = 0.0
            acc += v
            cumulative.append(acc)

        ax.plot(dates, cumulative, marker="o")
        ax.set_xlabel("Time")
        ax.set_ylabel("Cumulative Volume Change (m³)")
        ax.set_title("Cumulative Volume Change Over Time")
        ax.grid(True)
        self.figure.autofmt_xdate()
        self.canvas.draw()

