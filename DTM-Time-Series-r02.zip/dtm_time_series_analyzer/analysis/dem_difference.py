import os
from typing import Optional, Dict, Any

import numpy as np
from osgeo import gdal
from qgis.core import QgsRasterLayer


class DemDifferenceCalculator:
    """
    Compute DEM of Difference (DoD) rasters between consecutive DTM rasters.

    Assumes rasters share the same projection, resolution, and extent.
    """

    def compute_difference(
        self,
        path1: str,
        path2: str,
        output_suffix: str = "_DoD",
        add_to_canvas: bool = True,
        iface=None,
    ) -> Optional[Dict[str, Any]]:
        """
        Compute DEM2 - DEM1 and write result to GeoTIFF.

        Returns a dict containing:
            - diff_path: path to output GeoTIFF
            - diff_array: numpy array of differences
            - geotransform: GDAL geotransform tuple
        or None if computation fails.
        """
        ds1 = gdal.Open(path1)
        ds2 = gdal.Open(path2)
        if ds1 is None or ds2 is None:
            return None

        band1 = ds1.GetRasterBand(1)
        band2 = ds2.GetRasterBand(1)

        arr1 = band1.ReadAsArray().astype(float)
        arr2 = band2.ReadAsArray().astype(float)

        if arr1.shape != arr2.shape:
            # For simplicity we require same grid; real-world plugin could resample.
            return None

        nodata1 = band1.GetNoDataValue()
        nodata2 = band2.GetNoDataValue()

        mask = np.ones_like(arr1, dtype=bool)
        if nodata1 is not None:
            mask &= arr1 != nodata1
        if nodata2 is not None:
            mask &= arr2 != nodata2

        diff = np.zeros_like(arr1, dtype=float)
        diff[mask] = arr2[mask] - arr1[mask]
        diff[~mask] = np.nan

        driver = gdal.GetDriverByName("GTiff")
        base2 = os.path.splitext(os.path.basename(path2))[0]
        out_name = f"{base2}{output_suffix}.tif"
        out_path = os.path.join(os.path.dirname(path2), out_name)

        out_ds = driver.Create(out_path, ds2.RasterXSize, ds2.RasterYSize, 1, gdal.GDT_Float32)
        out_ds.SetGeoTransform(ds2.GetGeoTransform())
        out_ds.SetProjection(ds2.GetProjection())
        out_band = out_ds.GetRasterBand(1)
        out_band.WriteArray(diff)
        out_band.SetNoDataValue(np.nan)
        out_band.FlushCache()
        out_ds.FlushCache()

        if add_to_canvas and iface is not None:
            layer_name = os.path.basename(out_path)
            layer = QgsRasterLayer(out_path, layer_name)
            if layer.isValid():
                iface.addRasterLayer(out_path, layer_name)

        return {
            "diff_path": out_path,
            "diff_array": diff,
            "geotransform": ds2.GetGeoTransform(),
        }

