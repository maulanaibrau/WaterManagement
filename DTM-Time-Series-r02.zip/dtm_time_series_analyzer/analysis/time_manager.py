from datetime import datetime
from typing import List

from qgis.core import QgsMapLayer, QgsDateTimeRange, QgsMessageLog, Qgis
from qgis.PyQt.QtCore import QDateTime


class TimeManager:
    """
    Assign temporal properties to raster layers so they can be visualized
    with QGIS' native temporal controller.
    """

    def assign_temporal_properties(self, layers: List[QgsMapLayer], dates: List[datetime]):
        if not layers or not dates or len(layers) != len(dates):
            return

        for layer, date in zip(layers, dates):
            # Use the temporal properties object provided by the layer
            props = layer.temporalProperties()
            start = QDateTime(date.year, date.month, date.day, 0, 0)
            end = QDateTime(date.year, date.month, date.day, 23, 59)
            props.setIsActive(True)
            rng = QgsDateTimeRange(start, end)

            # QGIS versions differ in raster temporal API. Prefer fixed range when available.
            try:
                if hasattr(props, "setFixedTemporalRange"):
                    # Some builds require setting a mode first
                    if hasattr(props, "setMode") and hasattr(props, "ModeFixedTemporalRange"):
                        props.setMode(props.ModeFixedTemporalRange)
                    props.setFixedTemporalRange(rng)
                elif hasattr(props, "setTemporalRange"):
                    props.setTemporalRange(rng)
                else:
                    QgsMessageLog.logMessage(
                        f"Temporal properties API not supported for layer: {layer.name()}",
                        "DTM Time Series Analyzer",
                        level=Qgis.Warning,
                    )
            except Exception as e:
                # Never crash analysis because of temporal metadata assignment
                QgsMessageLog.logMessage(
                    f"Failed to assign temporal range for layer '{layer.name()}': {e}",
                    "DTM Time Series Analyzer",
                    level=Qgis.Warning,
                )
            layer.triggerRepaint()

